<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>