<?php echo e($slot); ?>

<?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>