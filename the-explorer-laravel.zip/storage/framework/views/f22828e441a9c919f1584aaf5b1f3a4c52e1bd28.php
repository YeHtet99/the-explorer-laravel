<?php $__env->startSection('title'); ?>
    Edit Post : The Explorer
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="mb-0">Update Post</h4>

                    <i class="fas fa-calendar"><?php echo e(date("d M Y")); ?></i>
                </div>
                <form action="<?php echo e(route('post.update',$post->id)); ?>" method="post" enctype="multipart/form-data" id="form-update">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-floating rounded mb-4">
                        <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('title',$post->title)); ?>" name="title" id="postTitle" placeholder="no need">
                        <label for="postTitle">Post Title</label>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback ps-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <input type="file" name="cover" id="cover" class="d-none" accept="image/jpeg,image/png">
                        <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" alt="" id="cover-preview" class="w-100 rounded cover-img  <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"">
                        <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback ps-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating mb-4">
                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 400px"><?php echo e(old('description',$post->description)); ?></textarea>
                        <label for="floatingTextarea2">Share Your Experience</label>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback ps-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </form>
                <div class="border rounded p-4 mb-4" id="gallery">
                    <div class="d-flex align-items-stretch">
                        <div class="border rounded px-5 d-flex justify-content-center align-items-center me-2" style="height: 150px" id="inputUi">
                            <i class="fas fa-upload"></i>
                        </div>
                        <div class="d-flex overflow-scroll me-2" style="height:150px">
                            <?php $__empty_1 = true; $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <img src="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>" class="rounded h-100">

                                <form action="<?php echo e(route('gallery.destroy',$gallery->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">
                                        <i class="fas fa-trash-alt fa-fw"></i>
                                    </button>
                                </form>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="mb-0">There is No Photo</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form action="<?php echo e(route('gallery.store')); ?>" method="post" enctype="multipart/form-data" id="gallery-upload">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" >
                        <div>
                            <input type="file" id="gallery-input" name="galleries[]" multiple class="d-none <?php $__errorArgs = ['galleries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['galleries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['galleries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="invalid-feedback"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['galleries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="invalid-feedback"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>
                </div>
                <div class="text-center">
                    <button class="btn btn-lg btn-primary" form="form-update">
                        <i class="fas fa-message"></i>
                        Update Post</button>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let coverPreview=document.querySelector("#cover-preview");
        let cover=document.querySelector("#cover");
        coverPreview.addEventListener("click",function (){
            cover.click();
        });
        cover.addEventListener("change",function (){
            let file=cover.files[0];
            let reader=new FileReader();
            reader.onload=function (){
                coverPreview.src=reader.result;
            }
            reader.readAsDataURL(file);
        })

        let inputUi=document.getElementById('inputUi');
        let galleryInput=document.getElementById('gallery-input');
        let galleryUpload=document.getElementById('gallery-upload');
        inputUi.addEventListener('click',function (){
            galleryInput.click();
        })
        galleryInput.addEventListener('change',function (){
            galleryUpload.submit();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/post/edit.blade.php ENDPATH**/ ?>