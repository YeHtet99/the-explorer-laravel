<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1><?php echo e($post->title); ?></h1>
<p><?php echo e($post->excerpt); ?></p>
    <a href="<?php echo e(route('post.detail',$post->slug)); ?>">Read More</a>
</body>
</html>
<?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/post/mail.blade.php ENDPATH**/ ?>