<?php $__env->startSection('content'); ?>


        <div class="container">
            <div class="row justify-content-center">

                <div class="col-lg-8">
                    <?php if(auth()->guard()->check()): ?>
                    <div class="d-flex justify-content-between align-items-center border p-4 rounded-3 mb-3">

                        <h4 class="">Welcome
                            <br>
                            <span class="fw-bold"><?php echo e(auth()->user()->name); ?></span>
                        </h4>

                        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-lg btn-primary">Create Post</a>
                    </div>
                    <?php endif; ?>
                    <div class="posts">
                       <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="post mb-4">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" alt="" class="rounded w-100 h-350" style="object-fit: cover">
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="d-flex flex-lg-column justify-content-between h-350 py-4">
                                            <div class="">
                                                <h4 class="fw-bold"><?php echo e($post->title); ?></h4>
                                                <p class="text-black-50 mb-0"><?php echo e($post->excerpt); ?></p>
                                            </div>
                                            <div>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="d-flex">
                                                        <img src="<?php echo e(asset($post->user->photo)); ?>" alt="" class="rounded-circle shadow-sm user-img me-1">
                                                        <p class="mb-0"><?php echo e($post->user->name); ?>

                                                            <br>
                                                            <i class="fas fa-calendar"></i>
                                                            <?php echo e($post->created_at->format("d M Y")); ?>

                                                        </p>
                                                    </div>
                                                    <a href="<?php echo e(route('post.detail',$post->slug)); ?>" class="btn btn-outline-primary">See More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                    </div>
                    <div class="d-flex justify-content-center mb-3">
                        <?php echo e($posts->links()); ?>

                    </div>
                </div>


            </div>

        </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/index.blade.php ENDPATH**/ ?>