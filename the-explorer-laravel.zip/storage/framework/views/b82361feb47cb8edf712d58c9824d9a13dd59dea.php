<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row justify-content-center">

            <div class="col-lg-8">
                        <div class="post mb-4">
                            <div class="row">
                                <h4 class="fw-bold mb-4"><?php echo e($post->title); ?></h4>
                                <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" alt="" class="rounded-3 w-100 h-350 mb-4" style="object-fit: cover">
                                <p class="text-black-50 mb-4 post-detail"><?php echo e($post->description); ?></p>
                                <?php if($post->galleries->count()): ?>
                                   <div class="gallery rounded border">
                                       <div class="row g-4 py-4">
                                           <h4 class="fw-bold text-center">Gallery</h4>
                                               <?php $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <div class="col-lg-4 col-xl-3 d-flex align-items-center justify-content-center">


                                                   <a class="venobox" data-gall="Lalisa" href="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>">
                                                       <img src="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>" class="gallery-photo">
                                                   </a>
                                               </div>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                       </div>

                                   </div>
                                <?php endif; ?>
                                <div class="mb-5 mt-3">
                                    <?php if(auth()->guard()->check()): ?>
                                    <h4 class="text-center fw-bold">User Comments</h4>
                                        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="comments mb-3 border rounded-3 p-3">

                                        <div class="d-flex justify-content-between align-items-md-baseline mb-3">
                                            <div class="d-flex">
                                                <img src="<?php echo e(asset($comment->user->photo)); ?>" alt="" class="rounded-circle shadow-sm user-img me-1">
                                                <p class="mb-0"><?php echo e($comment->user->name); ?>

                                                    <br>
                                                    <i class="fas fa-calendar"></i>
                                                    <?php echo e($comment->created_at->diffforhumans()); ?>

                                                </p>
                                            </div>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$comment)): ?>
                                            <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-outline-danger">
                                                    <i class="fas fa-trash-alt rounded-circle"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <p class="mb-0">
                                                <?php echo e($comment->message); ?>

                                            </p>
                                        </div>
                                    </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p class="">There is no comment</p>
                                        <?php endif; ?>
                                    <div class="row justify-content-center">
                                        <div class="col-lg-12">

                                            <form action="<?php echo e(route('comment.store')); ?>" method="post" id="comment-create">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-floating mb-3">
                                                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                                    <input type="text" name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="floatingInput" placeholder="Noneed" style="height: 150px;">
                                                    <label for="floatingInput">Comments</label>
                                                </div>
                                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                               <div class="text-center">
                                                   <button class="btn btn-primary">Add Comment</button>
                                               </div>
                                            </form>
                                        </div>
                                    </div>
                                        <?php endif; ?>
                                </div>
                                <div class="d-flex justify-content-between align-items-center rounded p-2 border">
                                    <div class="d-flex">
                                        <img src="<?php echo e(asset($post->user->photo)); ?>" alt="" class="rounded-circle shadow-sm user-img me-1">
                                        <p class="mb-0"><?php echo e($post->user->name); ?>

                                            <br>
                                            <i class="fas fa-calendar"></i>
                                            <?php echo e($post->created_at->format("d M Y")); ?>

                                        </p>
                                    </div>
                                    <div>
                                        <?php if(auth()->guard()->check()): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$post)): ?>
                                        <form action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post" class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-outline-danger">
                                                <i class="fas fa-trash-alt fa-fw"></i>
                                            </button>
                                        </form>
                                            <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
                                        <a href="<?php echo e(route('post.edit',$post->id)); ?>" class="btn btn-outline-warning">
                                            <i class="fas fa-pencil-alt fa-fw"></i>
                                        </a>
                                                <?php endif; ?>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('index')); ?>" class="btn btn-outline-primary">See All</a>
                                    </div>
                                </div>


                            </div>
                        </div>
            </div>



        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/post/detail.blade.php ENDPATH**/ ?>