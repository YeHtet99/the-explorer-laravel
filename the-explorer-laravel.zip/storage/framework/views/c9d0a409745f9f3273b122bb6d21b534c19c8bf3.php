<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="d-flex justify-content-between align-items-center border p-4 rounded-3">

                        <h4 class="">Welcome
                            <br>
                            <span class="fw-bold"><?php echo e(auth()->user()->name); ?></span>
                        </h4>

                        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-lg btn-primary">Create Post</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/index.blade.php ENDPATH**/ ?>
