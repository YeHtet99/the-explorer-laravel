<?php $__env->startSection('title'); ?> Change Password <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row min-vh-100">
            <div class="d-flex justify-content-center">
                <div class="col-lg-6 col-xl-5">
                    <div class="text-center mb-3">
                        <h4 class="fw-bold">Update Password</h4>
                        <img src="<?php echo e(auth()->user()->photo); ?>" alt="" class="profile-img mb-3">
                        <p class=""><?php echo e(auth()->user()->name); ?></p>
                        <p class=""><?php echo e(auth()->user()->email); ?></p>
                    </div>
                    <form action="<?php echo e(route('update-Password')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="password" class="<?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="currentPassword" name="old_password" placeholder="name@example.com">
                            <label for="currentPassword">Current Password</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" name="password" id="floatingPassword" placeholder="Password">
                            <label for="floatingPassword">New Password</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="floatingPassword" name="confirmPassword" placeholder="Password">
                            <label for="floatingPassword">Confirm Password</label>
                        </div>
                        <div class="text-center">
                            <button class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/Profile/changePassword.blade.php ENDPATH**/ ?>