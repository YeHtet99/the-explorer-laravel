<?php $__env->startSection('title'); ?> Edit Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row min-vh-100">
            <div class="d-flex justify-content-center">
            <div class="col-lg-6 col-xl-5">
                <div class="text-center mb-3">
                    <h4>Edit Profile</h4>
                    <img src="<?php echo e(auth()->user()->photo); ?>" alt="" class="profile-img">
                    <p class="mb-0"><?php echo e(auth()->user()->name); ?></p>
                    <p class="mb-0"><?php echo e(auth()->user()->email); ?></p>
                </div>
                <form action="<?php echo e(route('update-Profile')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="file" name="photo" accept="image/jpeg,image/png" class="d-none">
                    <div class="form-floating mb-3">
                        <input type="text" name="name" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" id="YourName" value="<?php echo e(auth()->user()->name); ?>" placeholder="name@example.com">
                        <label for="YourName">Your Name</label>
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-floating mb-3">
                        <input type="text" disabled class="form-control" id="floatingPassword"value="<?php echo e(auth()->user()->email); ?>" placeholder="Password">
                        <label for="floatingPassword">Your Email</label>
                    </div>
                   <div class="text-center">
                       <button class="btn btn-primary">Update</button>
                   </div>
                </form>
            </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let profileImage=document.querySelector('.profile-img');
        let profileInput=document.querySelector("[name='photo']");
        profileImage.addEventListener('click',function (){
            profileInput.click()
        })
        profileInput.addEventListener('change',function (){
            let file=profileInput.files[0];
            let reader=new FileReader();
            reader.onload=function (){
                profileImage.src=reader.result;
            }
            reader.readAsDataURL(file);
        })

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\the-explorer-laravel\the-explorer-laravel\resources\views/Profile/edit-Profile.blade.php ENDPATH**/ ?>